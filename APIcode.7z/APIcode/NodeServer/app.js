const _ = require('lodash');
const express = require('express')
var cors = require('cors');
const app = express()
const bodyParser = require('body-parser');
 
var locations = [
    "Hastings Castle",
    "Hastings Slieve Donard Hotel",
    "Hastings Everglades Hotel",
    "Hastings Railway Station",
    "Hastings Culloden Estate",
    "Hastings Europa Hotel",
    "Hastings District",
    "Hastingleigh",
    "Hastingwood",
    "Hastings Stormont",
    "Hastings Ballygally Castle Hotel",
    "Hastings Culloden Estate & Spa",
    "Hastings Slieve Donard Resort And Spa"
  ];


function GetLocation(loc)
{ 
	console.log(loc);
    var foundLoc = [];
    for(i = 0; i<locations.length; i++)
    {
        if(locations[i].toLowerCase().search(loc) != -1)
        {
            foundLoc.push(locations[i]);
            console.log(locations[i]);
        }    
   }
    return foundLoc;
}
 

app.use(cors());
app.use(bodyParser.json());

app.get('/api/locations/:loc', function (req, res) {
    var locId = req.params.loc;
    res.type("json");
    res.send(GetLocation(locId));
});


 
app.listen(4000, function () {
    console.log('API Server listening on port 4000!')
});
